<?php
include 'config.php';
define('admin_dir'  , '../');
define('ad_lim',10);
include_once phpLib.'form.php';

?>