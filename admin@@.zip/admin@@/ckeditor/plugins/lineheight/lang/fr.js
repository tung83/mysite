CKEDITOR.plugins.setLang('lineheight','fr', {
    title: 'Hauteur de Ligne'
} );
